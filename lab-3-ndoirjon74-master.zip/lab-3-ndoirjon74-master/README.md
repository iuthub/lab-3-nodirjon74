# Lab 3

Finish all exercises given in `lab3.pdf` file in this repo. The initial source code for your lab is inside `web_site` folder.